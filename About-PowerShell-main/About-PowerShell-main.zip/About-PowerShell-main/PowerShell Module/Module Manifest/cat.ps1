function Get-CatFact {
    Invoke-RestMethod https://catfact.ninja/fact
}