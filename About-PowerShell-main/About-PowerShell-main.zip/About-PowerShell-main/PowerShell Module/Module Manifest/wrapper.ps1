. .\cat.ps1
. .\quote.ps1
. .\weather.ps1