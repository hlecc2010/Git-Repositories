function Get-Weather {

    Invoke-RestMethod https://wttr.in/

}