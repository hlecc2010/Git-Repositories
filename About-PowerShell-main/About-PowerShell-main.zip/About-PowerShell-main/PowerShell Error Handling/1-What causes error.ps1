function Start-Die
{
    Throw "Aaaargh I've died"
}
Start-Die